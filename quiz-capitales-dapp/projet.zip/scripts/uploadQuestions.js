const ipfsClient = require('ipfs-http-client');
const { create } = ipfsClient;

const client = create({ url: 'https://ipfs.infura.io:5001' });

async function uploadQuestions() {
    const questions = [
        { question: "Capitale de la France ?", answers: ["Paris", "Lyon", "Marseille", "Bordeaux"], correctAnswer: "Paris" },
        { question: "Capitale de l'Australie ?", answers: ["Sydney", "Canberra", "Melbourne", "Brisbane"], correctAnswer: "Canberra" }
        // Ajouter 18 autres questions similaires
    ];

    for (let i = 0; i < questions.length; i++) {
        const json = JSON.stringify(questions[i]);
        const { cid } = await client.add(json);
        console.log(`Question ${i + 1} CID: ${cid}`);
    }
}

uploadQuestions();
